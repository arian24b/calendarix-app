import type { NextConfig } from "next";
import { withSerwistInit } from "@serwist/next";

const nextConfig: NextConfig = {
  output: "standalone",
  trailingSlash: true,
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  experimental: {
    webpackBuildWorker: true,
    parallelServerBuildTraces: true,
    parallelServerCompiles: true,
    viewTransition: true,
  },
  reactStrictMode: true,
};

export default withSerwistInit({
  // Service worker configuration
  swSrc: "app/sw.ts",
  swDest: "public/sw.js",
  disable: process.env.NODE_ENV === "development",
  // Registration options
  registration: {
    register: true,
    scope: "/",
  },
  // PWA-specific options
  skipWaiting: true,
  runtimeCaching: [],
})(nextConfig);
