"use client";

import { useEffect, useState } from "react";
import { Toast } from "sonner";

const ServiceWorkerRegistration = () => {
  const [isOnline, setIsOnline] = useState(true);
  const [installPrompt, setInstallPrompt] = useState<Event | null>(null);
  const [showInstallPrompt, setShowInstallPrompt] = useState(false);

  useEffect(() => {
    // Register the service worker
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").then(
        (registration) => {
          console.log("Service Worker registered with scope:", registration.scope);
        },
        (err) => {
          console.error("Service Worker registration failed:", err);
        }
      );
    }

    // Online/offline detection
    const handleOnline = () => {
      setIsOnline(true);
      Toast.success("You are back online!");
    };

    const handleOffline = () => {
      setIsOnline(false);
      Toast.error("You are offline. Some features may be unavailable.");
    };

    // Check initial status
    setIsOnline(navigator.onLine);

    // Listen for online/offline events
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    // Handle "Add to Home Screen" functionality
    window.addEventListener("beforeinstallprompt", (e) => {
      // Prevent Chrome 67 and earlier from automatically showing the prompt
      e.preventDefault();
      // Stash the event so it can be triggered later
      setInstallPrompt(e);
      // Show UI indication to install the app
      if (!localStorage.getItem("pwaInstallPromptDismissed")) {
        setShowInstallPrompt(true);
      }
    });

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  const handleInstallClick = () => {
    setShowInstallPrompt(false);
    
    // Show the install prompt
    if (installPrompt) {
      (installPrompt as any).prompt();
      
      // Wait for the user to respond to the prompt
      (installPrompt as any).userChoice.then((choiceResult: {outcome: string}) => {
        if (choiceResult.outcome === "accepted") {
          console.log("User accepted the install prompt");
        } else {
          console.log("User dismissed the install prompt");
          // Remember that user dismissed the prompt
          localStorage.setItem("pwaInstallPromptDismissed", "true");
        }
        setInstallPrompt(null);
      });
    }
  };

  const handleDismissInstall = () => {
    setShowInstallPrompt(false);
    // Remember that user dismissed the prompt
    localStorage.setItem("pwaInstallPromptDismissed", "true");
  };

  return (
    <>
      {/* PWA Install Prompt */}
      {showInstallPrompt && (
        <div className="fixed bottom-0 inset-x-0 pb-2 sm:pb-5 z-50">
          <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8">
            <div className="p-2 rounded-lg bg-blue-600 shadow-lg sm:p-3">
              <div className="flex items-center justify-between flex-wrap">
                <div className="w-0 flex-1 flex items-center">
                  <span className="flex p-2 rounded-lg bg-blue-800">
                    <svg 
                      className="h-6 w-6 text-white" 
                      xmlns="http://www.w3.org/2000/svg" 
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      <path 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        strokeWidth={2} 
                        d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" 
                      />
                    </svg>
                  </span>
                  <p className="ml-3 font-medium text-white truncate">
                    Install Calendarix for the best experience
                  </p>
                </div>
                <div className="flex-shrink-0 sm:ml-3">
                  <button
                    type="button"
                    onClick={handleInstallClick}
                    className="mr-2 flex-shrink-0 bg-blue-700 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-blue-800 focus:ring-white rounded-md"
                  >
                    Install
                  </button>
                  <a
                    href="/pwa-install"
                    className="mr-2 flex-shrink-0 border border-white px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-blue-800 focus:ring-white rounded-md"
                  >
                    How to Install
                  </a>
                  <button
                    type="button"
                    onClick={handleDismissInstall}
                    className="flex-shrink-0 -mr-1 flex p-2 rounded-md hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-white"
                  >
                    <span className="sr-only">Dismiss</span>
                    <svg 
                      className="h-5 w-5 text-white" 
                      xmlns="http://www.w3.org/2000/svg" 
                      viewBox="0 0 20 20" 
                      fill="currentColor"
                    >
                      <path 
                        fillRule="evenodd" 
                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" 
                        clipRule="evenodd" 
                      />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Offline indicator */}
      {!isOnline && (
        <div className="fixed top-0 inset-x-0 z-50">
          <div className="bg-yellow-500 text-white text-center py-2 px-4">
            You are offline. Some features may be unavailable.
          </div>
        </div>
      )}
    </>
  );
};

export default ServiceWorkerRegistration;
